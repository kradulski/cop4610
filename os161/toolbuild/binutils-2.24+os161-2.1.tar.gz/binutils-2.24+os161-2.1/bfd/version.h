#define BFD_VERSION_DATE 20131202
#define BFD_VERSION @bfd_version@
#define BFD_VERSION_STRING  @bfd_version_package@ @bfd_version_string@
#define REPORT_BUGS_TO @report_bugs_to@
